#ifndef UTILS_H
#define UTILS_H

double box_noise();

double white_noise();

void initialize_rng(long seed);

#endif
